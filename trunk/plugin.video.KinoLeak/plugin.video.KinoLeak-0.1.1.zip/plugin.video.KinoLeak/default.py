#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
from BeautifulSoup import BeautifulSoup as BS
from t0mm0.common.net import Net
addon_id = 'plugin.video.KinoLeak'
addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(addon_id)
status = __settings__.getSetting("status")
datapath = __settings__.getAddonInfo('path')
channels = xbmc.translatePath(os.path.join(datapath, 'resources', 'images'))
sys.path.append(channels)
print sys.getfilesystemencoding()
files1 = (os.listdir(channels))
files=[]
for name in files1:
    files.append(name.decode(sys.getfilesystemencoding()).encode('utf-8'))
def CATEGORIES(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        soup = BS(link)
        panel = soup.findAll("div", {"class": "col_1"})
        liste=BS(str (panel))
        for li in liste.findAll('li'):
            a=li.find('a')
            url= a['href']
            url=url.encode(sys.getfilesystemencoding())
            name= (a.text)
            name=(name.replace("&ouml;", "�".decode(sys.getfilesystemencoding())).replace(u'&Uuml;', "�".decode(sys.getfilesystemencoding()))).encode('utf-8')
            if any(name in s for s in files):
                addDir(name,'http://kinoleak.tv/'+url,1,str(channels)+"\\"+name+"-icon.png")
            else:
                addDir(name,'http://kinoleak.tv/'+url,1,str(channels)+"\\default.png")
        xbmc.executebuiltin("Container.SetViewMode(500)")
        
def INDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        soup = BS(link.decode(sys.getfilesystemencoding(),'ignore'))
        try:
            for div in soup.findAll('div',  {"class": "ca-genre-main"},smartQuotesTo=None):
                url = div.find('a')['href']
                img = div.find('img')['src']
                name = div.find('img')['title']
                addDir(name.encode('utf-8'),'http://kinoleak.tv/'+url,2,img)
        except:
                pass
        try:
            panel = soup.findAll("div", {"id": "site0"},smartQuotesTo=None)
            for td in soup.findAll("td", {"width": "48"},panel):
                a=td.find('a')
                url= a['href']
                thumb=td.find('img')['src']
                name= td.find('img')['title']
                addDir(name.encode('utf-8'),'http://kinoleak.tv/'+url,2,thumb)
        except:
                pass
                
        #############    N�chste Seite  >>>> #############
        try:
            page=re.compile('<strong>.*?</a></strong> <a href="(.*?)" id="button123">(.*?)</a>').findall(link)
            for Url,name in page:
                    addDir('Next [B]>>[/B]'+'[COLOR red][B]'+name+'[/B][/COLOR]','http://kinoleak.tv/'+Url,1,"")
        except:
            pass

        #############     Vorige Seite  <<<< #############
        try:
            page2=re.compile('<a href="(.*?)" id=".*?">.*?</a> <strong><a href=".*?" id=".*?">.*?</a></strong>').findall(link)
            for onUrl in page2:
                    addDir('Back','http://kinoleak.tv/'+onUrl,1,"")
        except:
            pass
        #############      ^^^^Hauptseite^^^^      #############
        try:
            addDir('Home','http://kinoleak.tv/',"","")	
        except:
            pass
        #############      ^^^^Gehe zur Seite^^^^      #############
        try:
            addDir('To Page','http://kinoleak.tv/'+Url,4,"")
        except:
            pass
        xbmc.executebuiltin("Container.SetViewMode(500)")
        
def GOTO_LEAK(Url):
        sayfagit = Url
        if 'page' in sayfagit:
            page1=re.compile('(.*?)&page=.*?').findall(sayfagit)
            for url in page1:
                git=url
        else:
            git=sayfagit
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=name_fix(query)
            url = (git+'&page='+query)
            return INDEX(url)
                
        xbmc.executebuiltin("Container.SetViewMode(400)")
        
def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

def VIDEOLINKS(url,name,img):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('IFRAME SRC="(.*?)"').findall(link)
        for i in match:
            print i
            addDir(name,i,3,img)
            
def resolve_mightyupload(name,url,img):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        html=response.read()
        file = re.search('file:.*?\'(.*?)\',',html,re.DOTALL)
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        try:
                addLink(name,file.group(1),img)
                listitem = xbmcgui.ListItem(name,thumbnailImage=img)
                url = file.group(1)
                xbmc.PlayList(1).add(url, listitem)
                xbmc.Player().play(pl)
        except Exception, e:
            dialog = xbmcgui.DialogProgress()
            dialog1 = xbmcgui.Dialog()
            dialog1.ok('error','[UPPERCASE][B]                Sorry but the video is deleted!!![/B][/UPPERCASE]')
            print '**** mightyupload Error occured: %s' % e
            raise
def resolve_cloudyvideos(name,url,img):
        net = Net()
        try:
            html = net.http_GET(url).content
        except urllib2.URLError, e:
            xbmc.executebuiltin('Notification("1","1")')
            return False
        r = re.search('name="op" value="(.*?)"', html)
        if r:
            op = r.group(1)
        else:
            xbmc.executebuiltin('Notification("1","1")')
            return False
        r = re.search('name="file_code" value="(.*?)"', html)
        if r:
            file_code = r.group(1)
        else:
            xbmc.executebuiltin('Notification("1","1")')
            return False
        r = re.search('name="referer" value="(.*?)"', html)
        if r:
            referer = r.group(1)
        else:
            xbmc.executebuiltin('Notification("1","1")')
            return False
        r = re.search('name="nwknj3" value="(.*?)"', html)
        if r:
            nwknj3 = r.group(1)
        else:
            xbmc.executebuiltin('Notification("1","1")')
            return False
        # post session_hash
        try:
            html = net.http_POST(url, form_data={'op': op, "file_code": file_code, "referer": referer, "nwknj3": nwknj3, 
                                                           'confirm': 'Continue as Free User'}).content
        except urllib2.URLError, e:
            xbmc.executebuiltin('Notification("1","1")')
            return False
        
        file=re.search("file: '(.*?)',", html)
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        try:
                addLink(name,file.group(1),img)
                listitem = xbmcgui.ListItem(name,thumbnailImage=img)
                url = file.group(1)
                xbmc.PlayList(1).add(url, listitem)
                xbmc.Player().play(pl)
        except Exception, e:
            dialog = xbmcgui.DialogProgress()
            dialog1 = xbmcgui.Dialog()
            dialog1.ok('error','[UPPERCASE][B]                Sorry but the video is deleted!!![/B][/UPPERCASE]')
            print '**** mightyupload Error occured: %s' % e
            raise
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=str(iconimage))
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None
img=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        img=urllib.unquote_plus(params["img"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES('http://kinoleak.tv/')
       
elif mode==1:
        print ""+url
        INDEX(url)
        
elif mode==2:
        print ""+url
        VIDEOLINKS(url,name,img)

elif mode==3:
        if 'vidhog' in url:
            resolve_vidhog(name,url,img)
        elif 'mightyupload' in url:
            resolve_mightyupload(name,url,img)
        elif 'vk.com' in url:
            resolve_VK(name,url,img)
        elif '180upload' in url:
            resolve_180upload(name,url,img)
        elif 'cloudyvideos' in url:
            resolve_cloudyvideos(name,url,img)
        else:
            pass
        
elif mode==4:
        print ""+url
        GOTO_LEAK(url)
        


xbmcplugin.endOfDirectory(int(sys.argv[1]))
