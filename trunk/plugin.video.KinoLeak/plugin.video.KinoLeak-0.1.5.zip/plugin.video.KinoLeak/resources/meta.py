from metahandler import common
def display_settings():
        common.addon.show_settings()

display_settings()
